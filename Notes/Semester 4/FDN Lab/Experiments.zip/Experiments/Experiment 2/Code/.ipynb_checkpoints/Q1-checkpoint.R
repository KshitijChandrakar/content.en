data("mtcars")
summary(mtcars)
