public class MathConstants {
    public static final double PI = 3.14159;

    public final void displayPI() {
        System.out.println("PI: " + PI);
    }
}
