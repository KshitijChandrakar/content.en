// Cant Inherit from Final Class
// public class ExtendedLogger extends Logger {
//     public void logMessage(String message) {
//         System.out.println("Extended Log: " + message);
//     }
// }
