public final class Logger {
    public void logMessage(String message) {
        System.out.println("Log: " + message);
    }
}
