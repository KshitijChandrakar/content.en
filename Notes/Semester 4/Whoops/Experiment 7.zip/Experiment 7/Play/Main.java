public class Main {
    public static void main(String[] args) {
        Playable player = new MusicPlayer();
        player.play();
        player.pause();
        player.stop();
    }
}
