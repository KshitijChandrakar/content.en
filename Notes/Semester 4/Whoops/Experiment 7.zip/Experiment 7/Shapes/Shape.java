abstract class Shape {
    public abstract void calculateArea();
}
